//Assign the copied API key to the 'key' variable
key = "1a193be0f6b135131128e4d1064c889c";